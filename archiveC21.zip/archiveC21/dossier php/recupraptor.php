<?php

/*******************************/
/*  COMMUNICATION DELIVRAPTOR  */
/*******************************/

/*
Classe passerelle permettant à un client PHP de communiquer
avec le serveur Delivraptor .

Elle encapsule :
 - l’authentification (CONN)
 - la création de bordereau (ADD)
 - la récupération d’état (ETA)
 - la récupération d’image (IMG)
 - la gestion du protocole (CMD / SIZE / END)
*/

class Recupraptor {

    /* Informations de connexion */
    private $user = NULL;
    private $password = NULL;
    private $ip = NULL;
    private $port = NULL;

    /* Ressource socket */
    private $conn = NULL;

    /* Données récupérées */
    private $numSuivi = NULL;
    private $etat = NULL;
    private $raison = NULL;
    private $image = NULL;

    /* Gestion d’erreur interne */
    private $err = NULL;


    /* ---------------------------------------------------------
       Constructeur : initialise les paramètres de connexion
       --------------------------------------------------------- */
    public function __construct($ip, $port, $user, $password){
        if (!$user || !$password || !$ip || !$port){
            throw new Exception("Erreur auth : user = {$user} password = {$password} ip = {$ip} port = {$port}");
        }

        $this->user = $user;
        $this->password = $password;
        $this->ip = $ip;
        $this->port = $port;
    }


    /* ---------------------------------------------------------
       Ouverture de la connexion + authentification (CONN)
       --------------------------------------------------------- */
    private function init_conn(): bool {

        /* Ouverture socket TCP */
        $this->conn = fsockopen($this->ip, $this->port, $errno, $errstr);

        if (!$this->conn){
            throw new Exception("Connexion failed : $errstr ($errno)");
        }

        /* Envoi commande CONN user password */
        $send = "CONN {$this->user} {$this->password}";

        if (!fwrite($this->conn, $send)) {
            fclose($this->conn);
            $this->conn = NULL;
            throw new Exception("Erreur send identifiants");
        }

        /* Lecture réponse serveur */
        $reponse = trim(fgets($this->conn));
        
        switch ($reponse) {
            case 'CONNECTION SUCCESS':
                return true;

            case 'CONNECTION DENIED':
                fclose($this->conn);
                $this->conn = NULL;
                throw new Exception("Connection denied : wrong username or password");

            default:
                fclose($this->conn);
                $this->conn = NULL;
                throw new Exception("Reponse inconnu : $reponse");
        }
    }


    /* ---------------------------------------------------------
       Fermeture propre de la connexion
       --------------------------------------------------------- */
    private function close_conn(): void {
        if ($this->conn){
            fclose($this->conn);
            $this->conn = NULL;
        }
    }


    /* ---------------------------------------------------------
       Envoi d’une commande au serveur + lecture protocole
       Format attendu :
           CMD <TYPE>
           SIZE <N>
           <message>
           END
       --------------------------------------------------------- */
    private function send_commande(string $commande) : string {
        $fin = 0;
        $len = 0;
        $message = "";

        /* Ouverture si nécessaire */
        if (!$this->conn){
            $this->init_conn();
        }

        /* Envoi de la commande brute */
        if (!fwrite($this->conn, $commande)){
            throw new Exception("Erreur envoie de la commande : $commande");
        }

        /* Lecture header CMD */
        $reponse = trim(fgets($this->conn));
        if (!preg_match("/^CMD\s([A-Z]+)$/", $reponse, $cmd)){
            throw new Exception("ERREUR CMD FORMAT : cmd " . $reponse);
        }

        /* Lecture header SIZE */
        $reponse = trim(fgets($this->conn));
        if (!preg_match("/^SIZE\s([0-9]+)$/", $reponse, $taille)){
            throw new Exception("ERREUR SIZE FORMAT : size " . $reponse);
        }

        /* Lecture du message selon la taille */
        if ($taille[1] < 255){
            /* Lecture ligne par ligne (texte) */
            while (!$fin){
                $reponse = trim(fgets($this->conn));
                if ($reponse != "END"){
                    $message .= $reponse;
                    $len += strlen($message);
                } else {
                    $fin = 1;
                }
            }
        } else {
            /* Lecture binaire (images) */
            while (!$fin){
                $reponse = fgets($this->conn);
                if (trim($reponse) != "END"){
                    $message .= $reponse;
                    $len += strlen($message);
                } else {
                    $fin = 1;
                }
            }
        }

        $this->close_conn();
        return $message;
    }


    /* ---------------------------------------------------------
       Création d’un bordereau (ADD)
       --------------------------------------------------------- */
    public function create_bord(string $numCommande, string $nomExp) {

        $cmd = sprintf("ADD %s %s", $nomExp, $numCommande);

        if ($reponse = $this->send_commande($cmd)){
            $this->numSuivi = $reponse;
            return $this->numSuivi;
        }

        throw new Exception("ERREUR non connecté");
    }


    /* ---------------------------------------------------------
       Conversion code état → texte lisible
       --------------------------------------------------------- */
    static private function etat_to_str($etat){
        switch ($etat){
            case "TRTC" : return "En attente";
            case "ACHTR" :
            case "ARRTR" :
            case "ACHPR" :
            case "ARRPR" :
            case "ACHCL" :
            case "ARRCL" : return "Expédié";
            case "LVRSN" : return "En cours de livraison";
            case "LVR"   : return "Livré";
            case "LVRAB" : return "Livré absent";
            case "REFU"  : return "Refusé";
            default      : return "Inconnu";
        }
    }


    /* ---------------------------------------------------------
       Récupération de l’état (ETA)
       --------------------------------------------------------- */
    public function get_etat(string $numSuivi){
        $message = NULL;
        
        if ($reponse = $this->send_commande("ETA $numSuivi")){

            /* Extraction du code état */
            if(!preg_match("/^([A-Z]+)\s/", $reponse, $res)){
                throw new Exception("ERREUR GET ETAT regex ETAT");
            }

            $etat_reponse = trim($res[1]);

            /* Cas refus → extraction message */
            if ($etat_reponse === "REFU"){
                if (!preg_match("/msg:\s*(.+)$/", $reponse, $res)){
                    throw new Exception("ERREUR GET ETAT regex MESSAGE");
                }
                $this->raison = $res[1];
            }

            /* Cas livraison avec anomalie → récupérer image */
            if ($etat_reponse === "LVRAB"){
                $this->get_img($numSuivi);
            }

            /* Conversion en texte lisible */
            $this->etat = Recupraptor::etat_to_str($etat_reponse);
            return $this->etat;
        }

        throw new Exception("ERREUR non connecté");
    }


    /* ---------------------------------------------------------
       Accesseurs simples
       --------------------------------------------------------- */
    public function get_raison(){
        return $this->raison;
    }

    public function get_image_url(){
        return $this->image;
    }


    /* ---------------------------------------------------------
       Récupération image (IMG)
       Le serveur renvoie les octets → écriture dans un fichier temporaire
       --------------------------------------------------------- */
    public function get_img(string $numSuivi){
        $racine = $_SERVER['DOCUMENT_ROOT'];
        $tmpDir = $racine . "/images/tmp_images";

        /* Création dossier si nécessaire */
        if (!is_dir($tmpDir)){
            mkdir($tmpDir, 0777, true);
        }

        /* Récupération binaire */
        if ($reponse = $this->send_commande("IMG $numSuivi")){

            /* Création fichier temporaire */
            $tmpFile = tempnam($tmpDir, "img_");
            $jpgFile = $tmpFile . ".jpg";
            rename($tmpFile, $jpgFile);

            /* Écriture image */
            file_put_contents($jpgFile, $reponse);

            /* URL publique */
            $url = "/tmp_images/" . basename($jpgFile);
            $this->image = $url;
        }
    }
}
?>
