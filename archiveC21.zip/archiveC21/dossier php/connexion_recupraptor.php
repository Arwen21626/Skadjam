<?php
include __DIR__ . "/recupraptor.php";
include __DIR__ . "/../recupraptor_connexions_params.php";

/* initialise la connexion au delivraptor avec la classe recupraptor*/

try{
    $rpr = new Recupraptor($rip, $rport, $ruser, $rpass);
} catch (Exception $e){
    echo "Erreur : " . $e->getMessage();
    die();
}

?>